<template>
  <!-- <input v-model="text" type="text" placeholder="Enter text to speak" />
  <button @click="synthesizeSpeech">Speak</button> -->
  <test/>
</template>

<script setup>
import test from './test.vue';
// import * as sdk from 'microsoft-cognitiveservices-speech-sdk';
// import { ref } from 'vue';

// const text = ref('');

// function synthesizeSpeech(){
//   const speechConfig = sdk.SpeechConfig.fromSubscription("7a9947bb80e2430091e0166bacadb8ba", "eastus");
//     speechConfig.speechSynthesisLanguage = "zh-CN"; 
//     // speechConfig.speechSynthesisVoiceName = "en-US-JennyNeural";
//   const SpeechSynthesizer = sdk.SpeechSynthesizer; 

//     const audioConfig = sdk.AudioConfig.fromDefaultSpeakerOutput();
    
//   const speechSynthesizer = new SpeechSynthesizer(speechConfig, audioConfig);
//     speechSynthesizer.speakSsmlAsync(
//         text.value,
//         result => {
          
//             if (result) {
//               console.log(result.audioData);
//                 speechSynthesizer.close();
//                 return result.audioData
//             }
//         },
//         error => {
//             console.log(error);
//             speechSynthesizer.close();
//         });
// } 

</script> 